# OBSStudioVideoUploadPlugin

A plugin to upload video from OBS Studio.

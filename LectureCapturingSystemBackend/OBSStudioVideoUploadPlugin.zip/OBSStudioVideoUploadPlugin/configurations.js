var configurations = {
    apiUrl: "http://localhost:5000"
};